import java.awt.*;
import java.applet.*;

public class MidPointCircle extends Applet 
{
	int maxX,maxY,centerX,centerY,dGrid=1;
	public void init()
	{
		Dimension d;
		d = getSize();
		maxX = d.width -1;
		maxY = d.height -1;
		centerX = maxX/2;
		centerY = maxY/2;
		setBackground(Color.black);
		setForeground(Color.white);
	}
	void drawCircle(Graphics g,int x,int y,int x_coordinate,int y_coordinate)
	{
	     g.fillOval((int)(x+x_coordinate),(int)(y+y_coordinate),5,5);
		 g.fillOval((int)(y+x_coordinate),(int)(x+y_coordinate),5,5);
		 g.fillOval((int)(y+x_coordinate),(int)(-x+y_coordinate),5,5);
		 g.fillOval((int)(x+x_coordinate),(int)(-y+y_coordinate),5,5);
		 g.fillOval((int)(-x+x_coordinate),(int)(-y+y_coordinate),5,5);
		 g.fillOval((int)(-y+x_coordinate),(int)(-x+y_coordinate),5,5);
		 g.fillOval((int)(-x+x_coordinate),(int)(y+y_coordinate),5,5);
		 g.fillOval((int)(-y+x_coordinate),(int)(x+y_coordinate),5,5);
	}
	void MidPointCircle(Graphics g,int x_coordinate, int y_coordinate, int radious)
	{
		int d = 1-radious;
		int x = 0;int y = radious;
		drawCircle(g,x,y,x_coordinate,y_coordinate);
		while(x<=y)
		{
			if(d<0)
			{
				d += 2*x + 3;
			}
			else{
				y--;
				d += 2*(x-y)+5;
			}
			x++;
			drawCircle(g,x,y,x_coordinate,y_coordinate);
		}
	}
	
	public void paint(Graphics g)
	{
		MidPointCircle(g,centerX,100,50);
	}
}
/* <applet code="MidPointCircle" width=1280 height=720> </applet> */