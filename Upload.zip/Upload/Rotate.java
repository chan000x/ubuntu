import java.awt.*;
import java.applet.*;

public class Rotate extends Applet
{
	int centerX,centerY,maxX,maxY,dGrid=1;
	public void init()
	{
		Dimension d;
		d = getSize();
		maxX = d.width;
		maxY = d.height;
		centerX = maxX/2;
		centerY = maxY/2;
		setBackground(Color.black);
		setForeground(Color.white);
	}
	public void drawLine(Graphics g,double x1,double y1,double x2,double y2)
	{
		double x,y,step,Xinc,Yinc;
		double dx = x2-x1;
		double dy = y2-y1;
		if(Math.abs(dx)>Math.abs(dy))
		{
			step = Math.abs(dx);
		}
		else{
			step = Math.abs(dy);
		}
		x = x1;
		y = y1;
		Xinc = dx/step;
		Yinc = dy/step;
		g.fillOval((int)x,(int)y,5,5);
		for(int i=1;i<step;i++)
		{
			x += Xinc;
			y += Yinc;
			g.fillOval((int)x,(int)y,5,5);
		}
	}
	public void Rotate(Graphics g,double a[][],int n,int x_pivot, int y_pivot, double angle)
	{
		double theta = Math.toRadians(angle);
		double sinTheta = Math.sin(Math.toRadians(angle));
		double cosTheta = Math.cos(Math.toRadians(angle));
		for(int i=0;i<a.length;i++)
		{
				double x = a[i][0]-x_pivot;
				double y = a[i][1]-y_pivot;
				
				a[i][0] = (x * cosTheta - y * sinTheta) + x_pivot;
				a[i][1] = (x * sinTheta + y * cosTheta) + y_pivot;
		}
		
	}
	 void Rotation(Graphics g, int x0, int y0, double P[][], double angle) {
        double cosTheta = Math.cos(Math.toRadians(angle));
        double sinTheta = Math.sin(Math.toRadians(angle));

        for (int i = 0; i < P.length; i++) {
            double x = P[i][0] - x0;
            double y = P[i][1] - y0;

            P[i][0] = x * cosTheta - y * sinTheta + x0;
            P[i][1] = x * sinTheta + y * cosTheta + y0;
        }
    }
	public void drawPolygon(Graphics g,double a[][],int n)
	{
		for(int i=0;i<n;i++)
		{
			if(i<n-1)
			{
				drawLine(g,a[i][0],a[i][1],a[i+1][0],a[i+1][1]);
			}
			else{
				drawLine(g,a[i][0],a[i][1],a[0][0],a[0][1]);
			}
		}
	}
	public void paint(Graphics g)
	{
		double a[][] = {{centerX,centerY},{centerX+100,centerY},{centerX+50,centerY-100}};
		double n[][]={{100,200},{200,200},{200,500},{100,500}};
		drawPolygon(g,a,3);
	    drawPolygon(g,n,4);
		g.setColor(Color.red);
		Reflect(g,centerX,centerY,n);
		drawPolygon(g,n,4);
		Reflect(g,centerX,0,n);
		drawPolygon(g,n,4);
		Reflect(g,0,centerY,n);
		drawPolygon(g,n,4);
		g.setColor(Color.blue);
		Reflect(g,centerX,centerY,a);
		drawPolygon(g,a,3);
		Reflect(g,centerX,0,a);
		drawPolygon(g,a,3);
		//Reflect(g,0,centerY,a);
		//drawPolygon(g,a,3);
		//Rotation(g,centerX+50,centerY-100,a,90);
		//Rotate(g,a,3,centerX,centerY,90);
		//drawPolygon(g,a,3);
		
		//g.drawRect(12,23,100,200);
		//drawLine(g,centerX+200,centerY,centerX,centerY);
	}
	public void Reflect(Graphics g,int x_coordinate,int y_coordinate,double a[][])
	{
		for(int i=0;i<a.length;i++)
		{
			double x = a[i][0]-x_coordinate;
			double y = a[i][1]-y_coordinate;
			if(y_coordinate == 0)
			{
				a[i][0] = (x * (-1))+x_coordinate;
			}
			else if(x_coordinate == 0)
			{
				a[i][1] = (y * (-1))+y_coordinate;
			}
			else{
				a[i][0] = (x * (-1))+x_coordinate;
				a[i][1] = (y * (-1))+y_coordinate;
			}
			
		}
	}
}
/* <applet code="Rotate" width=1280 height=720> </applet> */