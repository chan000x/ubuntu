import java.awt.*;
import java.applet.*;

public class BresenhamLine extends Applet 
{
	int MaxX,MaxY,centerX,centerY,dGrid=1;
	
	
	public void init()
	{
		Dimension d;
		d = getSize();
		MaxX = d.width -1;
		MaxY = d.height -1;
		centerX = MaxX/2;
		centerY = MaxY/2;
		setBackground(Color.black);
		setForeground(Color.white);
	}
	void BresenhamLine(Graphics g,int x1,int y1,int x2,int y2)
	{
		int dx,dy,d,inc1,inc2,x,y,end;
		dx = Math.abs(x2 - x1);
		dy = Math.abs(y2 - y1);
		int sx = x2-x1>0?1:-1;
		int sy = y2-y1>0?1:-1;
		if(dy/dx<1)
		{
			d = 2*dy - dx;
			inc1 = 2*dy;
			inc2 = 2*dy - 2*dx;
			
			g.fillOval(x1,y1,5,5);
			while(x2>x1)
			{
				if(d<0)
				{
					d += inc1;
				}
				else{
					y1+=sy;
					d += inc2;
				}
				x1 += sx;
				g.fillOval(x1,y1,5,5);
			}
		}
		else{
			d = 2*dx - dy;
			inc1 = 2*dx;
			inc2 = 2*dx - 2*dy;
			g.fillOval(x1,y1,5,5);
			while(y2>y1)
			{
				if(d<0)
				{
					d += inc1;
				}
				else{
					x1+=sx;
					d += inc2;
				}
				y1 += sy;
				g.fillOval(x1,y1,5,5);
			}
		}
	}
	public void paint(Graphics g)
	{
		//BresenhamLine(g,20,100,20,500);
		BresenhamLine(g,20,100,100,100);
		BresenhamLine(g,0,0,centerX,centerY);
		BresenhamLine(g,200,200,1000,1000);
		//BresenhamLine(g,centerX+100,centerY+200,centerX,centerY);
	}
}
/* 
<applet code=BresenhamLine width=1280 height=720> </applet>
*/