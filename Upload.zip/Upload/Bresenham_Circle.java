import java.awt.*;
import java.applet.*;

public class Bresenham_Circle extends Applet 
{
	int maxX,maxY,centerX,centerY,dGrid=1;
	public void init()
	{
		Dimension d;
		d = getSize();
		maxX = d.width;
		maxY = d.height;
		centerX = maxX/2;
		centerY = maxY/2;
		setBackground(Color.black);
		setForeground(Color.yellow);
	}
	void drawCircle(Graphics g,int x,int y,int x_coordinate,int y_coordinate)
	{
		g.fillOval((x+x_coordinate),(y+y_coordinate),5,5);
		g.fillOval((y+x_coordinate),(x+y_coordinate),5,5);
		g.fillOval((x+x_coordinate),(-y+y_coordinate),5,5);
		g.fillOval((y+x_coordinate),(-x+y_coordinate),5,5);
		g.fillOval((-x+x_coordinate),(-y+y_coordinate),5,5);
		g.fillOval((-y+x_coordinate),(-x+y_coordinate),5,5);
		g.fillOval((-x+x_coordinate),(y+y_coordinate),5,5);
		g.fillOval((-y+x_coordinate),(x+y_coordinate),5,5);
	}
	void Bresenham_Circle(Graphics g,int x_coordinate,int y_coordinate,int radious)
	{
		int d = 3-2*radious;
		int x = 0;int y = radious;
		drawCircle(g,x,y,x_coordinate,y_coordinate);
		while(x<=y)
		{
			if(d<0)
			{
				d+=4*x+6;
			}
			else{
				y--;
				d+=4*(x-y)+10;
			}
			x++;
			drawCircle(g,x,y,x_coordinate,y_coordinate);
		}
	}
	public void paint(Graphics g)
	{
		Bresenham_Circle(g,centerX,50,50);
	}
}
/* <applet code="Bresenham_Circle" width=1280 height=720> </applet> */