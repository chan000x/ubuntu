import java.awt.*;
import java.applet.*;

public class Scaling extends Applet 
{
	int maxX,maxY,centerX,centerY,dGrid=1;
	public void init()
	{
		Dimension d;
		d = getSize();
		maxX = d.width;
		maxY = d.height;
		centerX = maxX/2;
		centerY = maxY/2;
		setBackground(Color.black);
		setForeground(Color.white);
	}
	public void drawLine(Graphics g,int x1,int y1, int x2, int y2)
	{
		int dx = x2-x1;
		int dy = y2-y1;
		int step;
		double inc1,inc2,x,y;
		if(Math.abs(dx)>Math.abs(dy))
		{
			step = Math.abs(dx);
		}
		else
		{
			step = Math.abs(dy);
		}
		x = x1;
		y = y1;
		inc1 = (double)(dx/step);
		inc2 = (double)(dy/step);
		g.fillOval(Math.round((int)x),Math.round((int)y),5,5);
		for(int i=1;i<=step;i++)
		{
			y = y+inc2;
			x = x+inc1;
			g.fillOval(Math.round((int)x),Math.round((int)y),5,5);
		}
		
	}
	public void Scaling(Graphics g,int x[],int y[],int sx,int sy)
	{
		int n = x.length;
		for(int i=0;i<n;i++)
		{
			x[i] = (int)(x[i] * sx);
			y[i] = (int)(y[i] * sy);
		}
	}
	
	public void drawObj(Graphics g,int x[],int y[])
	{
		int n = x.length;
		for(int i=0;i<n;i++)
		{
			if(i<n-1)
			{
				drawLine(g,x[i],y[i],x[i+1],y[i+1]);
			}
			else{
				drawLine(g,x[i],y[i],x[0],y[0]);
			}
		}
	}
	public void Translation(Graphics g,int x[],int y[],int tx,int ty)
	{
		for(int i=0;i<x.length;i++)
		{
			x[i] += tx;
		}
		for(int i=0;i<y.length;i++)
		{
			y[i] += ty;
		}
	}
	public void paint(Graphics g)
	{
		int x[] = {centerX,centerX+100,centerX+100,centerX};
		int y[] = {centerY,centerY,centerY+100,centerY+100};
		drawObj(g,x,y);
		Translation(g,x,y,-centerX,-centerY);
		Scaling(g,x,y,2,3);
		Translation(g,x,y,centerX,centerY);
		drawObj(g,x,y);
	}
	
}
/* <applet code="Scaling" width=1280 height=720> </applet> */