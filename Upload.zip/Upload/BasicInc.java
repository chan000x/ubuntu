import java.awt.*;
import java.applet.*;

public class BasicInc extends Applet
{
	int Xmax,Ymax,centerX,centerY,dGrid = 1;
	public void init()
	{
		Dimension d;
		d = getSize();
		Xmax = d.width -1;
		Ymax = d.height -1;
		centerX = Xmax/2;
		centerY = Ymax/2;
	}
	public void paint(Graphics g)
	{
		BasicInc(g,100,300,100,30);
	}
	void BasicInc(Graphics g,double x1, double y1, double x2, double y2)
	{
		double dx,dy,m,rv;
		int x,y;
		dx = x2-x1;
		dy = y2-y1;
		if(dx != 0)
		{
			m = dy/dx;
			rv= y1;
			for(x=(int)Math.round(x1);x<= Math.round(x2);x++)
			{
				y=(int)Math.round(rv);
				g.fillOval((int)x,(int)y,5,5);
				rv+=m;
			}
		}
		else{
			if(dy == 0)
			{
				g.fillOval((int)x1,(int)y1,5,5);
			}
			else{
				y=(int)y1>(int)y2?(int)y2:(int)y1;
				for(;y<Math.abs(dy);y++)
				{
					g.fillOval((int)x1,(int)y,5,5);
				}
			}
		}
	}
}
/* <applet code="BasicInc" width = 500 height = 500> </applet> */