import java.awt.*;
import java.applet.*;

public class DDA extends Applet 
{
	int centerX,centerY,xMax,yMax,dGrid = 1;
	public void init()
	{
		Dimension d;
		d = getSize();
		xMax = d.width - 1;
		yMax = d.height - 1;
		centerX = xMax / 2; centerY = yMax / 2;
	}
	void DDA(Graphics g,int x1, int y1, int x2, int y2)
	{
		int dx = x2-x1;
		int dy = y2-y1;
		int step;
		double inc1,inc2,x,y;
		if(Math.abs(dx)>Math.abs(dy))
		{
			step = Math.abs(dx);
		}
		else
		{
			step = Math.abs(dy);
		}
		x = x1;
		y = y1;
		inc1 = (double)(dx/step);
		inc2 = (double)(dy/step);
		g.fillOval(Math.round((int)x),Math.round((int)y),5,5);
		for(int i=1;i<=step;i++)
		{
			y = y+inc2;
			x = x+inc1;
			g.fillOval(Math.round((int)x),Math.round((int)y),5,5);
		}
		
	}
	
	public void paint(Graphics g)
	{
		DDA(g,10,200,100,10);
	}
}
/* <applet code = DDA height = 500 width = 500> </applet> */